-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2019 at 08:31 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_login_id` varchar(80) NOT NULL,
  `admin_password` varchar(80) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_address` text NOT NULL,
  `admin_phone_no` varchar(20) NOT NULL,
  `admin_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin_uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_login_id`, `admin_password`, `admin_name`, `admin_address`, `admin_phone_no`, `admin_cid`, `admin_uid`) VALUES
(1, '0007', 'skaran92145', 'Karan', 'BH-2 Room No. 122 CDLU', '9466067763', '2019-04-29 09:02:01', '2019-05-02 02:53:10');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `student_id` int(11) NOT NULL,
  `attendance` varchar(30) NOT NULL DEFAULT 'Absent',
  `attendance_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `attendance_uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `attendance_date`, `student_id`, `attendance`, `attendance_cid`, `attendance_uid`) VALUES
(10, '2019-05-02', 26, 'Present', '2019-05-02 14:58:04', '2019-05-02 14:58:04');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(80) NOT NULL,
  `department_id` int(11) NOT NULL,
  `course_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `course_uid` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `department_id`, `course_cid`, `course_uid`) VALUES
(8, 'MCA (3 Year)', 31, '2019-05-02 12:52:05', '2019-05-02 12:52:05'),
(9, 'MTech', 31, '2019-05-02 12:52:11', '2019-05-02 14:52:55'),
(10, 'MCA(LE)', 31, '2019-05-02 12:52:23', '2019-05-02 12:52:23');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(90) NOT NULL,
  `department_HOD` varchar(80) NOT NULL,
  `department_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `department_uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`, `department_HOD`, `department_cid`, `department_uid`) VALUES
(7, 'Biotechnology', 'Prof. Raj Kumar', '2019-05-02 12:42:06', '2019-05-02 12:42:06'),
(8, 'Business Administration', 'Prof. Sultan Singh', '2019-05-02 12:42:20', '2019-05-02 12:42:20'),
(9, 'Chemistry', 'Prof. Dilbag Singh', '2019-05-02 12:42:57', '2019-05-02 12:42:57'),
(10, 'Commerce', 'Prof. Sultan Singh', '2019-05-02 12:43:13', '2019-05-02 12:43:13'),
(12, 'Economics', 'Prof. Abhey Singh', '2019-05-02 12:43:41', '2019-05-02 12:43:41'),
(13, 'Education', 'Dr. Nivedita', '2019-05-02 12:43:53', '2019-05-02 12:43:53'),
(14, 'Energy & Environmental Sciences', 'Prof. Deepti Dharmani, DAA', '2019-05-02 12:44:04', '2019-05-02 12:44:04'),
(15, 'English', 'Prof. Deepti Dharmani', '2019-05-02 12:44:15', '2019-05-02 12:44:15'),
(16, 'Food Science & Technology', 'Prof. R.K.Salar', '2019-05-02 12:44:32', '2019-05-02 12:44:32'),
(17, 'Journalism & Mass Communication', 'Prof. Deepti Dharmani', '2019-05-02 12:44:50', '2019-05-02 12:44:50'),
(18, 'Law', 'Prof. J.S. Jakhar', '2019-05-02 12:45:04', '2019-05-02 12:45:04'),
(19, 'Mathematics', 'Prof. Aseem Miglani', '2019-05-02 12:45:15', '2019-05-02 12:45:15'),
(20, 'Physical Education', 'Prof. Monika Verma', '2019-05-02 12:45:27', '2019-05-02 12:45:27'),
(21, 'Physics', 'Prof. Sushil Kumar', '2019-05-02 12:45:40', '2019-05-02 12:45:40'),
(22, 'Public Administration', 'Prof. Vishnu Bhagwan', '2019-05-02 12:45:53', '2019-05-02 12:45:53'),
(23, 'Hindi', 'Prof. Deepti Dharmani', '2019-05-02 12:46:18', '2019-05-02 12:46:18'),
(24, 'Punjabi', 'Prof. Deepti Dharmani', '2019-05-02 12:46:33', '2019-05-02 12:46:33'),
(25, 'Sanskrit', 'Prof. Deepti Dharmani', '2019-05-02 12:46:50', '2019-05-02 12:46:50'),
(26, 'History & Archeology', 'Prof. Vishnu Bhagwan', '2019-05-02 12:47:05', '2019-05-02 12:47:05'),
(27, 'Geography', 'Prof. Vishnu Bhagwan', '2019-05-02 12:47:18', '2019-05-02 12:47:18'),
(28, 'Music (Vocal & Instrumental)', 'Prof. Vishnu Bhagwan', '2019-05-02 12:47:31', '2019-05-02 12:47:31'),
(29, 'Botany', 'Prof. R.K.Salar', '2019-05-02 12:47:44', '2019-05-02 12:47:44'),
(31, 'Computer Science', 'Prof. Vikram Singh', '2019-05-02 12:50:41', '2019-05-02 14:56:40');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `exam_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `exam_uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(80) NOT NULL,
  `student_father_name` varchar(80) NOT NULL,
  `student_roll_no` int(11) NOT NULL,
  `student_course` int(11) NOT NULL,
  `student_address` text NOT NULL,
  `student_mobile_no` varchar(20) NOT NULL,
  `student_login_id` varchar(50) NOT NULL,
  `student_password` varchar(30) NOT NULL,
  `image` text NOT NULL,
  `student_cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `student_uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `student_father_name`, `student_roll_no`, `student_course`, `student_address`, `student_mobile_no`, `student_login_id`, `student_password`, `image`, `student_cid`, `student_uid`) VALUES
(26, 'Karan Soni', 'Brij Lal', 10, 8, 'Ward No.7 Nameste Chowk Mameran Road Ellenabad, Near Data Hari Shah Aashram ', '9466067763', '1082019', 'Karan Soni@10', '1082019.png', '2019-05-02 14:55:03', '2019-05-02 14:55:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
