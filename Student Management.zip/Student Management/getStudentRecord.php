<!-- bootstrap-table -->
  <center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Student Name</th>
                           <th>Father Name</th>                          
                           <th>Roll No.</th>                          
                           <th>Course</th>                              
                           <th>Department</th>                              
                           <th>Address</th>
                           <th>Image</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $sql="SELECT *,course_name FROM student
    left join course ON student.student_course=course.course_id
    left join department ON course.department_id=department.department_id
    ORDER BY student_id DESC";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $row["student_name"];?></td>
            <td><?php echo $row["student_roll_no"];?></td>
            <td><?php echo $row["student_father_name"];?></td>
            <td><?php echo $row["course_name"];?></td>
            <td><?php echo $row["department_name"];?></td>
            <td><?php echo $row["student_address"];?></td>
            <td><img src="./admin/upload/<?php echo $row["image"];?>" class="img-fluid rounded-circle" style="width:60px;height:50px;cursor:pointer"></td>
      
         </tr>
       <?php 
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="./js/bootstrap-table.min.js"></script>  
                