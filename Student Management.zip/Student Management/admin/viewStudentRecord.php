<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Student - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <style>
        input,select,textarea{
            cursor:not-allowed;
        }
        </style>
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card">
              <div class="card-heading" style="background-color:#00BCD4">
                  <span class="fa fa-eye"></span>
                  View Student Information
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>

              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->

                <?php 
                  if(isset($_GET["student_id"])){
                    //   if student id is set
                      include "./db.php";
                      $student_id=$_GET["student_id"];
                      $sql="SELECT *,course_name FROM student left join course ON student.student_course=course.course_id WHERE student_id='$student_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                             <div class="row">

                             <!-- col1 start here -->
                            <div class="col-sm-2">
                                  <div class="form-group">
                                         <img src="./upload/<?php echo $row['image'];?>" alt="student image" style="width:100px;border-radius:100%">
                                   </div>
                            </div>
                            <!-- col1 end here -->

                            <!-- col1 start here -->
                            <div class="col-sm-5">
                                  <div class="form-group">
                                      <label>Student Name:</label><br>
                                      <input type="text" name="student_name" id="student_name" value="<?php echo $row["student_name"];?>" placeholder="Student Full Name" required autofocus disabled readonly> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-5">
                                  <div class="form-group">
                                      <label>Father Name:</label><br>
                                      <input type="text" name="student_father_name" value="<?php echo $row["student_father_name"];?>" id="student_father_name" placeholder="Student Father Name" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                              <!-- col3 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Roll No.:</label><br>
                                      <input type="number" value="<?php echo $row["student_roll_no"];?>" name="student_roll_no" id="student_roll_no" placeholder="Student Roll No."  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col3 end here -->

                             <!-- col4 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select. Course:</label><br>
                                      <select name="student_course" id="student_course" required disabled readonly> 
                                          <option><?php echo $row["course_name"];?></option>                                          
                                      </select>
                                  </div>
                            </div>
                            <!-- col4 end here -->

                                                             
                             <!-- col5 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Permanent Address of Student:</label><br>
                                      <textarea name="student_address" id="student_address" style="resize:none" placeholder="Student Permanent Address" required disabled readonly><?php echo $row["student_address"];?></textarea>
                                  </div>
                            </div>
                            <!-- col5 end here -->
                            
                            
                                <!-- col4 start here -->
                                <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Mobile No.:</label><br>
                                      <input type="tel" name="student_mobile_no" value="<?php echo $row['student_mobile_no']?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->                          

                            
                                <!-- col4 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Login ID</label><br>
                                      <input type="tel" value="<?php echo $row['student_login_id']?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                              <!-- col4 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Password</label><br>
                                      <input type="password" value="<?php echo $row['student_password']?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                               <!-- col4 start here -->
                               <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Added on</label><br>
                                      <input type="tel" value="<?php echo date("d-m-Y h:i:s a",strtotime($row['student_cid']));?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                            <!-- col4 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Updated on</label><br>
                                      <input class="text-success font-weight-bold" type="tel" value="<?php if($row['student_cid']===$row['student_uid']){echo 'Not Updated';}else{echo date("d-m-Y h:i:s a",strtotime($row['student_uid']));}?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                                                
                      
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>

                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
     
<!-- main script end here -->
</body>
</html>

