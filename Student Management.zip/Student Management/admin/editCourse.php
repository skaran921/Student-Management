<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Course - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #FF4500">
              <div class="card-heading" style="background-color:#FF4500">
                  <span class="fa fa-edit"></span>
                  Edit Course Information
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                <?php 
                  if(isset($_GET["course_id"])){
                    //   if student id is set
                      include "./db.php";
                      $course_id=$_GET["course_id"];
                      $sql="SELECT *,department_name,department.department_id as main_department_id FROM course LEFT JOIN department ON course.department_id=department.department_id WHERE course_id='$course_id' ORDER BY course_id DESC";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                            
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Student Name:</label><br>
                                      <input type="text" name="course_name" id="course_name" value="<?php echo $row["course_name"];?>" placeholder="Student Full Name" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->                           


                             <!-- col4 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select Department:</label><br>
                                      <select name="department_id" id="department_id" required> 
                                          <option value="<?php echo $row["main_department_id"];?>"><?php echo $row["department_name"];?></option>
                                          <option value="">Select Student Course</option>
                                          <?php 
                                             include "../db.php";
                                             $sql1="SELECT department_id,department_name from department ORDER BY department_name ASC";
                                             $result1=$conn->query($sql1);
                                             while($row1=$result1->fetch_assoc()){
                                                 ?>
                                                 <option value="<?php echo $row1['department_id'];?>"><?php echo $row1['department_name'];?></option>
                                                 <?php 
                                             }
                                          ?>
                                      </select>
                                  </div>
                            </div>
                            <!-- col4 end here -->

                           
                        
                        <!-- col 17 start -->
                        <div class="col-sm-6">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn" style="background-color:#FF4500"><i class="fa fa-check-circle"></i> Update Course Info</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $course_id=$_GET["course_id"];
             $course_name=$_POST["course_name"];
             $department_id=$_POST["department_id"];           
             include "../db.php";
             $sql="UPDATE course SET course_name='$course_name', department_id='$department_id' WHERE course_id='$course_id'";              
          
                        $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Course Information Updated!!!</center></div>",function(){window.opener.location.reload();window.close();});
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Course Information Not Updated!!!</center></i></div>");
</script>
 <?php
                        }
         }#isset
      ?>
<!-- main script end here -->
</body>
</html>

