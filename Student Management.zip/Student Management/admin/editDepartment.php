<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Department - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card">
              <div class="card-heading" style="background-color:#FF4500">
                  <span class="fa fa-edit"></span>
                  Edit Department Information
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                <?php 
                  if(isset($_GET["department_id"])){
                    //   if student id is set
                      include "./db.php";
                      $department_id=$_GET["department_id"];
                      $sql="SELECT * FROM department WHERE department_id='$department_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                            
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Department Name:</label><br>
                                      <input type="text" name="department_name" id="department_name" value="<?php echo $row["department_name"];?>" placeholder="Student Full Name" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>HOD Name:</label><br>
                                      <input type="text" name="department_HOD" value="<?php echo $row["department_HOD"];?>" id="department_HOD" required> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                        
                        <!-- col 17 start -->
                        <div class="col-sm-12">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn"><i class="fa fa-check-circle"></i> Update Department Info</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $department_id=$_GET["department_id"];
             $department_name=$_POST["department_name"];             
             $department_HOD=$_POST["department_HOD"];             
             include "../db.php";
             $sql="UPDATE department SET department_name='$department_name', department_HOD='$department_HOD' WHERE department_id='$department_id'";              
          
                        $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Department Information Updated!!!</center></div>",function(){window.opener.location.reload();window.close();});
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Department Information Not Updated!!!</center></i></div>");
</script>
 <?php
                        }
         }#isset
      ?>
<!-- main script end here -->
</body>
</html>

