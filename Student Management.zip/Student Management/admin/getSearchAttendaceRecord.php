<!-- bootstrap-table -->
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>Attendance_ID</th>
                           <th>Attendance Date</th>                                           
                           <th>Student ID</th>                          
                           <th>Attendnace</th>                          
                           <th>Added On</th>                 
                           <th>Updated On</th>                 
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $search_option=$_GET["search_option"];
   $search_value=$_GET["search_value"];
   $sql="SELECT * FROM attendance WHERE $search_option LIKE'%$search_value%' ORDER BY attendance_id DESC";
   $result=$conn->query($sql);
   $x=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $x;?></td>
            <td><?php echo $row["attendance_id"];?></td>
            <td><?php echo date("d-m-Y",strtotime($row["attendance_date"]));?></td>
            <td><?php echo $row["student_id"];?></td>
            <td><?php echo $row["attendance"];?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["attendance_cid"]));?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["attendance_uid"]));?></td>
              <td>
                <button class="btn btn-dark" onclick="goForView(<?php echo $row['attendance_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark" onclick="goForEdit(<?php echo $row['attendance_id'];?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark" onclick="alertify.confirm('Are you really want to delete this attendance detail\'s ?',function(){goForDelete(<?php echo $row['attendance_id'];?>)})"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 
       $x++;
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="../js/bootstrap-table.min.js"></script>  
                
<script>
function goForView(attendance_id){
  window.open(`viewAttendanceRecord.php?attendance_id=${attendance_id}`)
}

function goForEdit(department_id){
  window.open(`editAttendance.php?attendance_id=${attendance_id}`)
}

</script>