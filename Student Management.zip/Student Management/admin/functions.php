<!-- php functions -->
<?php 
function getTotalAdmin(){
    include "db.php";
    $sql="SELECT Count(*) as totalAdmin from admin";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalAdmin"];
    }
}
// end

function getTotalStudents(){
    include "db.php";
    $sql="SELECT Count(*) as total from student";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalDepartment(){
    include "db.php";
    $sql="SELECT Count(*) as total from department";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalCourse(){
    include "db.php";
    $sql="SELECT Count(*) as total from course";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalExams(){
    include "db.php";
    $sql="SELECT Count(*) as total from exams";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalTodayPresent(){
    include "db.php";
    $date=date("Y-m-d");
    $sql="SELECT Count(*) as total from attendance WHERE attendance='Present' AND attendance_date='$date'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalTodayAbsent(){
    include "db.php";
    $date=date("Y-m-d");
    $sql="SELECT Count(*) as total from attendance WHERE attendance='Absent' AND attendance_date='$date'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getAccountCreatedOn($admin_id){
    include "db.php";
    $sql="SELECT admin_cid from admin WHERE admin_id='$admin_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return date("d-F-Y",strtotime($row["admin_cid"]));
    }
}
// end

function getPasswordChangedOn($admin_id){
    include "db.php";
    $sql="SELECT admin_cid,admin_uid from admin WHERE admin_id='$admin_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        if($row["admin_cid"]===$row["admin_uid"]){
            return "Password Not Changed!!!";
        }else{
            return date("d-F-Y",strtotime($row["admin_uid"]));
        }
    }
}
// end
?>
<!-- php functions end-->