<?php 
  session_start();

  if(isset($_SESSION["student_admin_id"])){
      header("Location:./dashboard.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" keyword="Student Information System">
    <meta name="description" content="Student Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login - Student Information System</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
   
    <!-- external css -->
    <link rel="stylesheet" href="../css/index.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
       <!-- main div -->
         <div class="main">
                <center> 
                    <img src="../images/icon.png" alt="logo" class="icon">
                    <p class="heading"><span class="fas fa-user-secret"></span> Admin Panel</p>
                </center>  
               <form id="form" action="" method="post">
                     <div class="form-group">
                        <input type="text" name="admin_login_id" id="admin_login_id" placeholder="Admin ID" required autofocus>   
                        <input type="password" name="admin_password" id="admin_password" placeholder="Password" required >   
                      </div>                      
                           <button type="submit" name="login" class="admin_button"> <span class="fa fa-sign-in-alt"></span> Login</button>
                      
             

               <!-- php start here-->
   <?php 
      if(isset($_POST["login"])){
          $admin_login_id=$_POST["admin_login_id"];
          $admin_password=$_POST["admin_password"];
          include "../db.php";
          $sql=$conn->prepare("SELECT admin_id FROM admin WHERE admin_login_id=? AND admin_password=?");
          $sql->bind_param("ss",$admin_login_id,$admin_password);
          $sql->execute();
          $result=$sql->get_result();
          if($row=$result->fetch_assoc()){
                  $_SESSION["student_admin_id"]=$row["admin_id"];
                  header("Location:./dashboard.php");
          }else{
                ?>
                <center style="margin-top:10px;background-color:#EA425C;padding:4px;border-radius:7px;">
                   <span class="text-light"><i class='fa fa-times-circle'></i> Invalid Username OR Password!!!</span>
                </center>
                <?php
          }
          $sql->close();
      }
   ?>
<!-- php end here -->
</form>
        </div>
       <!-- main div end-->


       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<!-- <script src="./js/bootstrap.min.js"></script> -->
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
</body>
</html>

