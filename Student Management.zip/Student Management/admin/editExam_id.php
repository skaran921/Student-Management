<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Exam - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #1B1464">
              <div class="card-heading" style="background-color:#1B1464">
                  <span class="fa fa-edit"></span>
                  Edit Exam Result Information
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                <?php 
                  if(isset($_GET["exam_id"])){
                    //   if student id is set
                      include "./db.php";
                      $exam_id=$_GET["exam_id"];
                      $sql="SELECT * FROM exams WHERE exam_id='$exam_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                            
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Exam ID:</label><br>
                                      <input type="number" name="exam_id" id="exam_id" style="cursor:not-allowed" value="<?php echo $row["exam_id"];?>" disabled readonly required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->
                             
                             <!-- col2 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label> Select Student ID:</label><br>
                                      <select type="text" name="student_id" id="student_id" required> 
                                            <option><?php echo $row['student_id'];?></option>
                                            <option value="">Select Student ID</option>
                                            <?php 
                                               include "./db.php";
                                               $sql1="SELECT student_id from student";
                                               $result1=$conn->query($sql1);
                                               while($row1=$result1->fetch_assoc()){
                                                   ?>
                                                   <option><?php echo $row1['student_id'];?></option>
                                                   <?php
                                               }
                                            ?>
                                      </select>
                                  </div>
                            </div>
                            <!-- col2 end here -->
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Marks:</label><br>
                                      <input type="number" name="marks" id="marks" value="<?php echo $row["marks"];?>" placeholder="Type Marks Obtained By Student"  required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Total Marks:</label><br>
                                      <input type="number" name="total_marks" id="total_marks" value="<?php echo $row["total_marks"];?>" placeholder="Type Total Marks OF Exam" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->                            
                        
                        <!-- col 17 start -->
                        <div class="col-sm-12">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn"><i class="fa fa-check-circle"></i> Update Exam Info</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $exam_id=$_GET["exam_id"];
             $student_id=$_POST["student_id"];
             $marks=$_POST["marks"];
             $total_marks=$_POST["total_marks"];                   
             include "../db.php";
             $sql="UPDATE exams SET student_id='$student_id', marks='$marks', total_marks='$total_marks'
                     WHERE exam_id='$exam_id'";           
                        $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Student Information Updated!!!</center></div>",function(){window.opener.location.reload();window.close();});
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Exam Result Information Not Updated!!!</center></i></div>");
</script>
 <?php
                        }
         }#isset
      ?>
<!-- main script end here -->
</body>
</html>

