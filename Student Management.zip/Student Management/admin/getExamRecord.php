<!-- bootstrap-table -->
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>Exam_Result_ID</th>
                           <th>Student_ID</th>
                           <th>Marks</th>                          
                           <th>Total Marks</th>                          
                           <th>Percentage</th>                          
                           <th>Added On</th>                          
                           <th>Updated On</th>                 
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $sql="SELECT * FROM exams ORDER BY exam_id DESC";
   $result=$conn->query($sql);
   $x=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $x;?></td>
            <td><?php echo $row["exam_id"];?></td>
            <td><?php echo $row["student_id"];?></td>
            <td><?php echo $row["marks"];?></td>
            <td><?php echo $row["total_marks"];?></td>
            <td><?php echo round($row["marks"]/$row["total_marks"],4)*100;?>%</td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["exam_cid"]));?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["exam_uid"]));?></td>
              <td>
                <button class="btn btn-dark" onclick="goForView(<?php echo $row['exam_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark" onclick="goForEdit(<?php echo $row['exam_id'];?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark" onclick="alertify.confirm('Are you really want to delete this exam result Detail\'s ?',function(){goForDelete(<?php echo $row['exam_id'];?>)})"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 
       $x++;
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="../js/bootstrap-table.min.js"></script>  
                
<script>
function goForView(exam_id){
  window.open(`viewExamRecord.php?exam_id=${exam_id}`)
}

function goForEdit(exam_id){
  window.open(`editExam_id.php?exam_id=${exam_id}`)
}

</script>