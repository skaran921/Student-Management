<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Department - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addDepartment.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card">
              <div class="card-heading">
                  <span class="fa fa-plus"></span>
                  Add New Depart    ment
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Department Name:</label><br>
                                      <input type="text" name="department_name" id="department_name" placeholder="Type Department Name" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label> Department HOD Name:</label><br>
                                      <input type="text" name="department_HOD" id="department_HOD" placeholder=" Department HOD Name" required> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                        <!-- col 17 start -->
                        <div class="col-sm-12">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn"><i class="fa fa-check-circle"></i> Save Department</button>
                                    <button type="reset" class="button resetBtn"><i class="fa fa-refresh"></i> Reset Form</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $department_name=$_POST["department_name"];
             $department_HOD=$_POST["department_HOD"];                     
             include "../db.php";
             $sql1="SELECT department_id FROM department WHERE department_name='$department_name'";
             $sql="INSERT INTO department(department_name, department_HOD)VALUES('$department_name','$department_HOD')";
               $result1=$conn->query($sql1);
            // if record found
            if($row1=$result1->fetch_assoc()){
                  ?>
<script>
    alertify.alert("<p style='font-size:20px;color:#0652DD;'><i class='fa fa-times-circle'></i> Oops Departmet Record Already Exist</p>")
</script>
                  <?php 
            }else{
                         $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Department Information Saved!!!</div>");
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Department Information Not Saved!!!</center></i></div>");
</script>
 <?php
                        }
            }
         }  #isset
      ?>
<!-- main script end here -->
</body>
</html>

