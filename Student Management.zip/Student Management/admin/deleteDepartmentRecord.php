<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delete</title>
<link rel="stylesheet" href="../alertify/css/alertify.css">
<link rel="stylesheet" href="../fontawesome/css/all.css">

</head>
<body>
<?php 
include "./db.php";
$department_id=$_GET["department_id"];
$sql="DELETE FROM department WHERE department_id='$department_id'";
$result=$conn->query($sql);
$sql1="SELECT department_id FROM course WHERE department_id='$department_id'";
$result1=$conn->query($sql1);
if($row=$result1->fetch_assoc()){
   ?>
   <script src="../alertify/js/alertify.js"></script>
<script>
   alertify.alert("<div style='font-size:22px;color:#FF9800'><i class='fa fa-exclamation-circle'></i> Not allowed because Department info currently in used!!!</div>",function(){window.close();});
</script>
   <?php 
}else{
if($result==TRUE){
   ?>
<script src="../alertify/js/alertify.js"></script>
<script>
   alertify.alert("<div style='font-size:22px;color:green;'><i class='fa fa-check-circle'></i> Deleted!!!</div>",function(){window.opener.location.reload();window.close();});
</script>
   <?php 
}else{
    ?>
<script src="../alertify/js/alertify.js"></script>
<script>
   alertify.alert("<div style='font-size:22px; class='text-info'><i class='fa fa-times-circle'></i>error!!!</div>",function(){window.close();});
</script>
   <?php 
}
}
?>
</body>
</html>


