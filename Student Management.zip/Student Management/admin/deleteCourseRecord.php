<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delete Course</title>
<link rel="stylesheet" href="../alertify/css/alertify.css">
<link rel="stylesheet" href="../fontawesome/css/all.css">

</head>
<body>
<?php 
include "./db.php";
$course_id=$_GET["course_id"];
$sql1="SELECT student_course FROM student WHERE student_course='$course_id'";
$sql="DELETE FROM course WHERE course_id='$course_id'";
$result1=$conn->query($sql1);
if($row1=$result1->fetch_assoc()){
    ?>
<script src="../alertify/js/alertify.js"></script>
<script>
alertify.alert("<div style='font-size:22px;color:red;'><i class='fa fa-times-circle'></i> Not Allowed Because This Course Already In Use!!!</div>",function(){window.opener.location.reload();window.close();});
</script>
    <?php   
}else{
// if delete alllowed
$result=$conn->query($sql);
if($result==TRUE){
?>
<script src="../alertify/js/alertify.js"></script>
<script>
alertify.alert("<div style='font-size:22px;color:green;'><i class='fa fa-check-circle'></i> Deleted!!!</div>",function(){window.opener.location.reload();window.close();});
</script>
<?php 
}else{
    ?>
<script src="../alertify/js/alertify.js"></script>
<script>
alertify.alert("<div style='font-size:22px; class='text-info'><i class='fa fa-times-circle'></i>error!!!</div>",function(){window.close();});
</script>
<?php 
}
}#else fetch_Assoc()
?>
</body>
</html>


