<?php 
  session_start();

  if(isset($_SESSION["student_admin_id"])){
  }else{
    header("Location:./index.php");
  }
?>