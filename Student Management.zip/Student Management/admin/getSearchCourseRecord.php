<!-- bootstrap-table -->
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>Course_ID</th>
                           <th>Course Name</th>                                           
                           <th>Added On</th>                          
                           <th>Updated On</th>                 
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $search_option=$_GET["search_option"];
   $search_value=$_GET["search_value"];
   $sql="SELECT * FROM course WHERE $search_option LIKE'%$search_value%' ORDER BY course_id ASC";
   $result=$conn->query($sql);
   $x=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $x;?></td>
            <td><?php echo $row["course_id"];?></td>
            <td><?php echo $row["course_name"];?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["course_cid"]));?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["course_uid"]));?></td>
              <td>
                <button class="btn btn-dark" onclick="goForView(<?php echo $row['course_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark" onclick="goForEdit(<?php echo $row['course_id'];?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark" onclick="alertify.confirm('Are you really want to delete this Course Detail\'s ?',function(){goForDelete(<?php echo $row['department_id'];?>)})"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 
       $x++;
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="../js/bootstrap-table.min.js"></script>  
                
<script>
function goForView(department_id){
  window.open(`viewDepartmentRecord.php?department_id=${department_id}`)
}

function goForEdit(department_id){
  window.open(`editDepartment.php?department_id=${department_id}`)
}

</script>