<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Attendance Record - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <style>
        input,select,textarea{
            cursor:not-allowed;
        }
        </style>
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #fa625f;">
              <div class="card-heading" style="background-color:#fa625f">
                  <span class="fa fa-eye"></span>
                  Attendance information
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>

              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->

                <?php 
                  if(isset($_GET["attendance_id"])){
                    //   if student id is set
                      include "./db.php";
                      $attendance_id=$_GET["attendance_id"];
                      $sql="SELECT * FROM attendance WHERE attendance_id='$attendance_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                             <div class="row">


                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Attendance ID:</label><br>
                                      <input type="text" value="<?php echo $row["attendance_id"];?>" required  disabled readonly> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Attendance Date:</label><br>
                                      <input type="text" value="<?php echo date("d-m-Y",strtotime($row["attendance_date"]));?>" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                              <!-- col3 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Student ID:</label><br>
                                      <input type="text" value="<?php echo $row["student_id"];?>"  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col3 end here -->   

                            
                              <!-- col3 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Attendance:</label><br>
                                      <input type="text" value="<?php echo $row["attendance"];?>"  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col3 end here -->   

                               <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Added on</label><br>
                                      <input type="tel" value="<?php echo date("d-m-Y h:i:s a",strtotime($row['attendance_cid']));?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                            <!-- col4 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Updated on</label><br>
                                      <input class="text-success font-weight-bold" type="tel" value="<?php if($row['attendance_cid']===$row['attendance_uid']){echo 'Not Updated';}else{echo date("d-m-Y h:i:s a",strtotime($row['attendance_uid']));}?>" id="student_mobile_no" placeholder="Student Mobile No."  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                                                
                      
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>

                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
     
<!-- main script end here -->
</body>
</html>

