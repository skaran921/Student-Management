<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Department Record - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
    <style>
        input,select,textarea{
            cursor:not-allowed;
        }
        </style>
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #fa625f;">
              <div class="card-heading" style="background-color:#fa625f">
                  <span class="fa fa-eye"></span>
                  View Department information
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>

              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->

                <?php 
                  if(isset($_GET["department_id"])){
                    //   if student id is set
                      include "./db.php";
                      $department_id=$_GET["department_id"];
                      $sql="SELECT * FROM department WHERE department_id='$department_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                             <div class="row">


                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Department ID:</label><br>
                                      <input type="text" value="<?php echo $row["department_id"];?>" required autofocus disabled readonly> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Department Name:</label><br>
                                      <input type="text" value="<?php echo $row["department_name"];?>" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                              <!-- col3 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>HOD Name.:</label><br>
                                      <input type="text" value="<?php echo $row["department_HOD"];?>"  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col3 end here -->   
                               <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Added on</label><br>
                                      <input type="tel" value="<?php echo date("d-m-Y h:i:s a",strtotime($row['department_cid']));?>" id="student_mobile_no" placeholder="Student Mobile No." maxlength="10" required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                            <!-- col4 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Detail's Updated on</label><br>
                                      <input class="text-success font-weight-bold" type="tel" value="<?php if($row['department_cid']===$row['department_uid']){echo 'Not Updated';}else{echo date("d-m-Y h:i:s a",strtotime($row['department_uid']));}?>" id="student_mobile_no" placeholder="Student Mobile No."  required disabled readonly> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  

                                                
                      
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>

                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
     
<!-- main script end here -->
</body>
</html>

