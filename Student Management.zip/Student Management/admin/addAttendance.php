<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Attendance - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addCourse.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #3C40C6">
              <div class="card-heading" style="background:#3C40C6">
                  <span class="fa fa-plus-circle"></span>
                  Add Attendance
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                        <div class="row">
                        
                           <!-- col2 start here -->
                           <div class="col-sm-6">
                                  <div class="form-group">
                                      <label> Select Date (if not current date):</label><br>
                                      <input type="date" name="attendance_date" value="<?php echo date('Y-m-d');?>" id="attendance_date" required>    
                                  </div>
                            </div>
                            <!-- col2 end here -->
            
                             <!-- col2 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label> Select Student ID:</label><br>
                                      <select type="text" name="student_id" id="student_id" required autofocus> 
                                            <option value="">Select Student ID</option>
                                            <?php 
                                               include "./db.php";
                                               $sql1="SELECT student_id from student";
                                               $result1=$conn->query($sql1);
                                               while($row=$result1->fetch_assoc()){
                                                   ?>
                                                   <option value="<?php echo $row['student_id'];?>"><?php echo $row["student_id"];?></option>
                                                   <?php
                                               }
                                            ?>
                                      </select>
                                  </div>
                            </div>
                            <!-- col2 end here -->

                             <!-- col2 start here -->
                           <div class="col-sm-6">
                                  <div class="form-group">
                                      <label> Attendance</label><br>
                                      <select name="attendance" id="attendance" required>
                                           <option value="">Select Attendance</option>
                                           <option>Present</option>
                                           <option>Absent</option>
                                      </select>    
                                  </div>
                            </div>
                            <!-- col2 end here -->

                        <!-- col 17 start -->
                        <div class="col-sm-12">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn" style="background-color:#009688"><i class="fa fa-check-circle"></i> Save Attendance</button>
                                    <button type="reset" class="button resetBtn"><i class="fa fa-refresh"></i> Reset Form</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $attendance_date=$_POST["attendance_date"];
             $student_id=$_POST["student_id"];                     
             $attendance=$_POST["attendance"];                     
             include "../db.php";
             $sql1="SELECT attendance_id FROM attendance WHERE student_id='$student_id' AND attendance_date='$attendance_date'";
             $sql="INSERT INTO attendance(attendance_date, student_id,attendance)VALUES('$attendance_date','$student_id','$attendance')";
               $result1=$conn->query($sql1);
            // if record found
            if($row1=$result1->fetch_assoc()){
                  ?>
<script>
    alertify.alert("<p style='font-size:20px;color:#0652DD;'><i class='fa fa-times-circle'></i> Oops today attendance of this student Already Exist</p>")
</script>
                  <?php 
            }else{
                         $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Course Information Saved!!!</div>");
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Course Information Not Saved!!!</center></i></div>");
</script>
 <?php
                        }
            }
         }  #isset
      ?>
<!-- main script end here -->
</body>
</html>

