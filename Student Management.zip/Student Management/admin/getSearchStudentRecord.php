<!-- bootstrap-table -->
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Student_ID</th>
                           <th>Student Name</th>
                           <th>Father Name</th>                          
                           <th>Roll No.</th>                          
                           <th>Course</th>                              
                           <th>Mobile No.</th>
                           <th>Image</th>
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $search_option=$_GET["search_option"];
   $search_value=$_GET["search_value"];
   $sql="SELECT *,course_name FROM student left join course ON student.student_course=course.course_id WHERE $search_option='$search_value' ORDER BY student_id DESC";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $row["student_id"];?></td>
            <td><?php echo $row["student_name"];?></td>
            <td><?php echo $row["student_roll_no"];?></td>
            <td><?php echo $row["student_father_name"];?></td>
            <td><?php echo $row["course_name"];?></td>
            <td><?php echo $row["student_mobile_no"];?></td>
            <td><img src="./upload/<?php echo $row["image"];?>" class="img-fluid rounded-circle" style="width:60px;height:50px;cursor:pointer"></td>
            <td>
                <button class="btn btn-dark" onclick="goForView(<?php echo $row['student_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark" onclick="goForEdit(<?php echo $row['student_id'];?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark" onclick="alertify.confirm('Are you really want to delete this student Detail\'s ?',function(){goForDelete(<?php echo $row['student_id'];?>)})"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="../js/bootstrap-table.min.js"></script>  
                
<script>
function goForView(student_id){
  window.open(`viewStudentRecord.php?student_id=${student_id}`)
}

function goForEdit(student_id){
  window.open(`editStudent.php?student_id=${student_id}`)
}

</script>