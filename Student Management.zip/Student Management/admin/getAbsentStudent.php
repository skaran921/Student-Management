<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Absent Student - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">
   
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/allDepartment.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">

     <!-- jquery.js -->
<script src="../js/jquery.js"></script>
<!-- popover min.js -->
<script src="../js/popper.min.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>

</head>

  <?php 
  ?>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
            <!-- main row start -->
         
         <div class="header" style="background-color:#FF3031">
            <span><i class="fa fa-list-alt"></i> Absent Student List</span>
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>
         </div>
            
           <div class="mainRow" id="data">     
           
                  <!-- bootstrap-table -->
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="57  0" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>Attendance_ID</th>
                           <th>Attendance Date</th>                                           
                           <th>Student ID</th>                          
                           <th>Attendnace</th>                          
                           <th>Added On</th>                 
                           <th>Updated On</th>                         
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $search_option="attendance";
   $search_value="Absent";
   $sql="SELECT * FROM attendance WHERE $search_option='$search_value' ORDER BY attendance_id DESC";
   $result=$conn->query($sql);
   $x=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $x;?></td>
            <td><?php echo $row["attendance_id"];?></td>
            <td><?php echo date("d-m-Y",strtotime($row["attendance_date"]));?></td>
            <td><?php echo $row["student_id"];?></td>
            <td><?php echo $row["attendance"];?></td>
            <td><?php echo date("d-m-Y h:i:s a",strtotime($row["attendance_cid"]));?></td>
            <td>
                <?php 
                    if($row["attendance_cid"]===$row["attendance_uid"]){
                          echo "<span style='color:green';font-weight:600;>Not Updated</span>";
                    }else{
                        echo date("d-m-Y h:i:s a",strtotime($row["attendance_uid"]));
                    }
                ?>
            </td>
         </tr>
       <?php 
       $x++;
   }
?>
                    </tbody>
               </table> 
           <center> 

<script type="text/javascript" src="../js/bootstrap-table.min.js"></script>  
            
           
            </div>
            <!-- main row end -->
     </div>    
    <!-- dashboard end-->
      

<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
</body>
</html>

