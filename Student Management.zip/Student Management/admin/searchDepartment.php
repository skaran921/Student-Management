<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Search Department - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/bootstrap-table.min.css">
   
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/searchDepartment.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">

     <!-- jquery.js -->
<script src="../js/jquery.js"></script>
<!-- popover min.js -->
<script src="../js/popper.min.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>

</head>

  <?php 
  ?>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
            <!-- main row start -->
         
         <div class="header">
            <span><i class="fa fa-search"></i> Search Department</span>
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>
         </div>
            <!-- header end and form start -->
            <form class="search_form" action="" method="post">
                   <label>Search By:</label>
                   <select name="search_option" id="search_option" required>
                       <option value="">Select Search Option</option>
                       <option value="department_name">Department Name</option>
                       <option value="deparment_HOD">HOD Name</option>
                       <option value="department_id">Department ID</option>                      
                   </select> 
                   <label>Search Value:</label>
                   <input type="text" name="search_value" id="search_value" placeholder="Enter Search Value eg. Student Roll No." required>                      
         <center style="margin-top:10px;">     
               <button type="submit" class="button saveBtn" onclick="serach()"><i class="fa fa-search"></i> Search</button>
               <button type="reset" class="button resetBtn"><i class="fa fa-redo"></i> Reset</button>
        </center>
            </form>
            <!-- form end -->
           <div class="mainRow" id="data">                     
            </div>
            <!-- main row end -->
     </div>    
    <!-- dashboard end-->
      

<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>



<script>
    function serach(){
        event.preventDefault();
        let search_option=document.querySelector("#search_option").value;
        let search_value=document.querySelector("#search_value").value;
        if(search_option==="" || search_value===""){
             alertify.alert("<div><i class='fa fa-exclamation-triangle'></i> All fields are required!!!</div>");
        }else{
             getDepartmentRecord(search_option,search_value);
        }
    }
function getDepartmentRecord(search_option,search_value){ 
            $.ajax({url: `getSearchDepartmentRecord.php?search_option=${search_option}&search_value=${search_value}`,
             success: function(result){
                        $("#data").html(result);
             }});
}

function goForDelete(student_id){
  window.open(`deleteStudentRecord.php?student_id=${student_id}`)
}
 
</script>
</body>
</html>

