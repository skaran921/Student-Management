<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Student - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="../fontawesome/css/brand.css">
    <link rel="stylesheet" href="../fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="../css/addStudent.css">
    <!-- alertify -->
    <link rel="stylesheet" href="../alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="../images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card" style="border-left:2px solid #FF4500">
              <div class="card-heading" style="background-color:#FF4500">
                  <span class="fa fa-edit"></span>
                  Edit Student Information
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                <?php 
                  if(isset($_GET["student_id"])){
                    //   if student id is set
                      include "./db.php";
                      $student_id=$_GET["student_id"];
                      $sql="SELECT *,course_name FROM student left join course ON student.student_course=course.course_id WHERE student_id='$student_id'";
                      $result=$conn->query($sql);
                      if($row=$result->fetch_assoc()){
                            ?>
                            
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Student Name:</label><br>
                                      <input type="text" name="student_name" id="student_name" value="<?php echo $row["student_name"];?>" placeholder="Student Full Name" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                              <!-- col2 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Father Name:</label><br>
                                      <input type="text" name="student_father_name" value="<?php echo $row["student_father_name"];?>" id="student_father_name" placeholder="Student Father Name" required> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                              <!-- col3 start here -->
                              <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Roll No.:</label><br>
                                      <input type="number" name="student_roll_no" value="<?php echo $row["student_roll_no"];?>" id="student_roll_no" placeholder="Student Roll No."  required> 
                                  </div>
                            </div>
                            <!-- col3 end here -->

                             <!-- col4 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select. Course:</label><br>
                                      <select name="student_course" id="student_course" required> 
                                          <option value="<?php echo $row["course_id"];?>"><?php echo $row["course_name"];?></option>
                                          <option value="">Select Student Course</option>
                                          <?php 
                                             include "../db.php";
                                             $sql1="SELECT course_id,course_name from course ORDER BY course_name ASC";
                                             $result1=$conn->query($sql1);
                                             while($row1=$result1->fetch_assoc()){
                                                 ?>
                                                 <option value="<?php echo $row1['course_id'];?>"><?php echo $row1['course_name'];?></option>
                                                 <?php 
                                             }
                                          ?>
                                      </select>
                                  </div>
                            </div>
                            <!-- col4 end here -->

                                 
                             <!-- col5 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Permanent Address of Student:</label><br>
                                      <textarea name="student_address" id="student_address" placeholder="Student Permanent Address" required> <?php echo $row["student_address"];?></textarea>
                                  </div>
                            </div>
                            <!-- col5 end here -->

                                <!-- col4 start here -->
                                <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Mobile No.:</label><br>
                                      <input type="tel" name="student_mobile_no" id="student_mobile_no"  value="<?php echo $row["student_mobile_no"];?>" placeholder="Student Mobile No." maxlength="10" required> 
                                  </div>
                            </div>
                            <!-- col4 end here -->  
                            
                             <!-- col16 start here -->
                          <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select Image:</label><br>
                                      <input type="file" name="image" accept="image/*" id="image" required>                                       
                                  </div>
                           </div>
                        <!-- col16 end here -->

                        
                        <!-- col 17 start -->
                        <div class="col-sm-6">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn"><i class="fa fa-check-circle"></i> Update Student Info</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                            <?php
                      }else{
                          ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                          <?php 
                      }#if record not found
                    
                  }else{
                      ?>
                         <center><h4 class="text-danger">Sorry No Record Found!!!</h4></center>
                      <?php 
                  }#if student id is not set
                ?>
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="../js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="../js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="../alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="../fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $student_id=$_GET["student_id"];
             $student_name=$_POST["student_name"];
             $student_father_name=$_POST["student_father_name"];
             $student_roll_no=$_POST["student_roll_no"];
             $student_course=$_POST["student_course"];
             $student_address=$_POST["student_address"];
             $student_mobile_no=$_POST["student_mobile_no"];
             $student_login_id=$student_roll_no.$student_course.date("Y");
             $student_password=$student_name."@".$student_roll_no;             
             $image=$_FILES["image"]["name"];
             $imageName=$student_login_id.".png";            
             include "../db.php";
             $sql="UPDATE student SET student_name='$student_name', student_father_name='$student_father_name', student_roll_no='$student_roll_no',
              student_course='$student_course', student_address='$student_address', student_mobile_no='$student_mobile_no',
              student_login_id='$student_login_id', student_password='$student_password', image='$imageName' WHERE student_id='$student_id'";              
          
                // if record not exist               
                   if(file_exists("upload/$year/$month")){                         
                   }else{
                     mkdir("upload/$year/$month",0777,true);        
                   }
                if(
                    move_uploaded_file($_FILES["image"]["tmp_name"],"upload/$year/$month/$imageName")
                  ){
                        $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light' style='font-size:25px;'><center><i class='fa fa-check-circle'></i> Student Information Updated!!!<br><b>Student Login ID:</b> <?php echo $student_login_id;?></center></i></div>",function(){window.opener.location.reload();window.close();});
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:25px;'><center><i class='fa fa-times-circle'></i> <br>Error... Student Information Not Updated!!!</center></i></div>");
</script>
 <?php
                        }
                }else{
                    // if files not uploaded
                    ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:18px'><center><p><i class='fas fa-times-circle' style='font-size:50px;'></i></p>Oops... Image OR ID Proff Not Uploaded!!!</center></i></div>");      
</script>
                    <?php 
                }
         }#isset
      ?>
<!-- main script end here -->
</body>
</html>

