<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Department - Student Info</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/bootstrap-table.min.css">
   
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/allDepartment.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="./images/icon.png" type="image/x-icon">

     <!-- jquery.js -->
<script src="./js/jquery.js"></script>
<!-- popover min.js -->
<script src="./js/popper.min.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>

</head>

  <?php 
  ?>
<body onload="getStudentAllRecord()">
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
            <!-- main row start -->
         
         <div class="header">
            <span><i class="fa fa-list-alt"></i> All Department List</span>
            <span style="float:right;cursor:pointer;margin-right:10px;" class="fa fa-print" onclick="window.print();"></span>
         </div>
            
           <div class="mainRow" id="data">                     
            </div>
            <!-- main row end -->
     </div>    
    <!-- dashboard end-->
      

<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>



<script>
function getStudentAllRecord(){ 
            $.ajax({url: "getDepartmentRecord.php",
             success: function(result){
                        $("#data").html(result);
             }});
}
 
</script>
</body>
</html>

