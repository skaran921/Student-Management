<!-- php functions -->
<?php 
function getTotalAdmin(){
    include "db.php";
    $sql="SELECT Count(*) as totalAdmin from admin";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalAdmin"];
    }
}
// end

function getTotalStudents(){
    include "db.php";
    $student_course_id=getStudentCourseID();
    $sql="SELECT Count(*) as total from student WHERE student_course='$student_course_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getStudentCourseID(){
    $student_id=$_SESSION["student_own_id"];
    include "db.php";
    $sql="SELECT student_course from student WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["student_course"];
    }
}
// end

function getTotalDepartment($student_id){
    include "db.php";
    $sql="SELECT department_name from student 
    left join course ON student.student_course=course.course_id
    left join department ON course.department_id=department.department_id 
    WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["department_name"];
    }
}
// end

function getTotalCourse($student_id){
    include "db.php";
    $sql="SELECT course_name from student 
    left join course ON student.student_course=course.course_id
    WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["course_name"];
    }
}
// end

function getTotalExams($student_id){
    include "db.php";
    $sql="SELECT Count(*) as total from exams WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalTodayPresent($student_id){
    include "db.php";
    $month=date("m");
    $sql="SELECT Count(*) as total from attendance WHERE student_id='$student_id' AND attendance='Present' AND Month(attendance_date)='$month'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getTotalTodayAbsent($student_id){
    include "db.php";
    $month=date("m");
    $sql="SELECT Count(*) as total from attendance WHERE student_id='$student_id' AND attendance='Absent' AND Month(attendance_date)='$month'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getAccountCreatedOn($student_id){
    include "db.php";
    $sql="SELECT student_cid from student WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return date("d-F-Y",strtotime($row["student_cid"]));
    }
}
// end

function getPasswordChangedOn($student_id){
    include "db.php";
    $sql="SELECT student_cid,student_uid from student WHERE student_id='$student_id'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        if($row["student_cid"]===$row["student_uid"]){
            return "Password Not Changed!!!";
        }else{
            return date("d-F-Y",strtotime($row["student_uid"]));
        }
    }
}
// end
?>
<!-- php functions end-->