<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard - Student Information System</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/dashboard.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="./images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
     include "./functions.php";
  ?>
 
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
            <!-- main row start -->
            <div class="row mainRow">
                <!-- col1 start -->
                  <div class="col-md-3 card" style="background-color:#2F363F !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-clock"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Time</p>
                                    
                                    <p class="details">
                                        <p id="time"></p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col1 end here -->
 

                  <!-- col2 start -->
                  <div class="col-md-3 card"  style="background-color:#FF362E !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fas fa-calendar-alt"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Date</p>
                                    
                                    <p class="details">
                                         <?php 
                                           echo date("D d-m-Y");
                                         ?>                                       
                                    </p>
                                                                      
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col2 end here -->

                  <!-- col3 start -->
                  <div class="col-md-3 card" onclick="window.open('getAdminList.php','_self')" style="background-color:#2ecc71 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-user-secret"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Total Admin</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalAdmin(); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col3 end here -->

                   <!-- col4 start -->
                   <div class="col-md-3 card" onclick="window.open('allDepartmentList.php','_self')" style="background-color:#1BCA9B !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-hotel"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Your Department </p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalDepartment($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col4 end here -->

                 <!-- col5 start -->
                 <div class="col-md-3 card" onclick="window.open('allCourseList.php','_self')" style="background-color:#2196F3 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-book"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Your Course</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalCourse($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col5 end here -->

                  <!-- col6 start -->
                  <div class="col-md-3 card" onclick="window.open('allExamList.php','_self')" style="background-color:#4834DF !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-book-open"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Exam Result</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalExams($_SESSION['student_own_id']); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col6 end here -->

                  <!-- col7 start -->
                  <div class="col-md-3 card" onclick="window.open('allStudentList.php','_self')" style="background-color:#192A56 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-user-circle"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Total Student's</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalStudents(); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col7 end here -->

                  <!-- col8 start -->
                  <div class="col-md-3 card" onclick="window.open('getPresentStudent.php','_self')" style="background-color:#FF9800 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-user-check"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Total Present's(Month)</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalTodayPresent($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col8 end here -->

                 <!-- col9 start -->
                 <div class="col-md-3 card" onclick="window.open('getAbsentStudent.php','_self')" style="background-color:#FF3031 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-user-times"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Total Absent's(Month)</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalTodayAbsent($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col9 end here -->

                 <!-- col10 start -->
                 <div class="col-md-3 card" onclick="window.open('getAccountInfo.php','_self')" style="background-color:#FF4500 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-id-card"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Account Created On</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getAccountCreatedOn($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col10 end here -->

                 <!-- col11 start -->
                 <div class="col-md-3 card" onclick="window.open('getAccountInfo.php','_self')" style="background-color:#00303F  !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-lock"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Password Changed On</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getPasswordChangedOn($_SESSION["student_own_id"]); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col11 end here -->

                 <!-- col12 start -->
                 <div class="col-md-3 card"  style="background-color:#111 !important;color:#fff;">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-info-circle"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> About Us</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            V 1.0 &copy; 2019
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col12 end here -->
  
            </div>
            <!-- main row end -->
     </div>    
    <!-- dashboard end-->

    <!-- footer -->
      <?php include "./footer.php";?>
    <!-- footer end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

<!-- clock script-->
<script>
      function clock(){
          let d=new Date();
          document.querySelector("#time").innerHTML=d.toLocaleTimeString();
      }
      setInterval(clock, 1000);
</script>
<!-- clock script end -->
</body>
</html>


