
<!-- navbar -->
<nav class="navbar navbar-expand-md navbar-dark  fixed-top" >
           <a href="./dashboard.php" class="navbar-brand">
               <img src="./images/icon.png" alt="logo" style="border-radius:30px;width:40px;">
               Student info
           </a>
          
           <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myMenu">
               <span class="navbar-toggler-icon"></span>
           </button>

           <div class="collapse navbar-collapse" id="myMenu">
               <ul class="navbar-nav mr-auto">
                <!-- student  -->
                    <li class="nav-item">
                          <a class="nav-link" href="./allStudentList.php"><span class="fas fa-user-graduate"></span> All Student's</a>                      
                    </li>
                <!-- student  end-->

                 <!-- Department  -->
                 <li class="nav-item">
                          <a class="nav-link" href="./allDepartmentList.php"><span class="fas fa-school"></span> Department's</a>                      
                    </li>
                <!-- Department  end-->


                <!-- other  -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fas fa-map-signs"></span> Other's
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="./todayAttendanceList.php"><span class="fas fa-user-clock"></span> My Attendnace</a>                      
                           
                          <div class="dropdown-divider"></div>    
                      <a class="dropdown-item" href="./searchExam.php"><span class="fas fa-search"></span> Search Exam Result</a>                     

                          <div class="dropdown-divider"></div>    
                    <a class="dropdown-item" href="./allCourseList.php"><span class="fas fa-list-alt"></span> All Course List</a>

                        </div>
                    </li>
                <!-- end -->
                    
                   
                      <!-- Settings dropdown -->
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fas fa-cogs"></span> Setting's
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#" onclick="document.querySelector('#myModal').style.display='block'"><span class="fas fa-lock"></span> Change Password</a>
                          <div class="dropdown-divider"></div>                       
                        </div>
                    </li>
                    <!-- Attendance dropdown end-->


                   
               </ul>
                   
                     <div class="admin_icon">                         
                          <?php 
                             include "./db.php";
                             $student_own_id=$_SESSION["student_own_id"];
                             $sql="SELECT student_name,image FROM student WHERE student_id='$student_own_id'";
                             $result=$conn->query($sql);
                             if($row=$result->fetch_assoc()){
                               ?>
                            <img src="./admin/upload/<?php echo $row['image'];?>" alt="admin" class="img-fluid admin_image">
                               <?php
                                 echo $row["student_name"];
                             }
                          ?>
                     </div>
                        <a href="javascript:void()" onclick="logout()" class="logOut_button"> 
                            <span class="fa fa-sign-out-alt"></span>                        
                        </a>

               <div>
                   
               </div>
           </div>
      </nav>
  <!-- navbar end-->

<script>
   function logout(){
       alertify.confirm("Logout?",()=>{window.location.href='logout.php'})
   }
</script>

<style>
    .dropdown-menu {
    border: none !important;
    border-bottom: 1px solid #0652dd !important;
    border-bottom-left-radius: 0 !important;
    border-bottom-right-radius: 0 !important;
    border-top: 2px solid #2ecc71 !important;
    transition: ease-in-out 1s;
}

body{
    background:#f4f4f4;
}

nav {
    background-color: #192A56 !important;
    color: #fff !important;
}

.logOut_button {
    text-decoration: none !important;
    color: #fff !important;
}

.admin_image {
    width: 40px;
    border-radius: 100%;
}

.admin_icon {
    margin-right: 10px;
    }

  .dialog>div {
    background-color: #fafafa !important;
    color: #111;
    font-weight: 700;
    border-radius: 4px;
}

.dialog>div .ok {
    background-color: #26ae60 !important;
    color: #fff !important;
}

.dialog>div .ok:hover {
    background-color: #4CAF50 !important;
    color: #fff !important;
}

.dialog>div .cancel {
    background-color: #FF3031 !important;
    color: #fff !important;
}

.dialog>div .cancel :hover {
    background-color: #F00 !important;
    color: #fff !important;
}

    /* width */
    ::-webkit-scrollbar {
  width: 7px;
  cursor:pointer;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #2c2c2c; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background:#00c07f; 
}



.modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            z-index:999;
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 40%;
            max-height: 400px;
            box-sizing: border-box;
            border-radius: 7px;
            -webkit-box-shadow: 0px 1px 3px 0 #666999;
            box-shadow: 0px 1px 3px 0 #666999;
            animation: modalAnimation 1s ease;
        }
        
        @keyframes modalAnimation {
            0% {
                transform: scale(0)
            }
            50% {
                transform: scale(1)
            }
        }


        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 0;
            right:0;
            margin-right:10px;
        }
        
        .close:hover {
            color: #FF3031;
            text-decoration: none;
            cursor: pointer;
        }

        .mainRow .card{
          transition:2s;
          animation: modalAnimation 2s ease;
        }

       .col-md-3 .row:hover{
             background-color:rgba(0,0,0,0.3);  
        }

        #changePassword input,
        textarea,
        select {
            display: block;
            width: 100%;
            margin: 4px;
            background: #f4f4f4;
            padding: 6px 10px;
            border: none;
            border-radius: 6px;
            outline-color: #2ecc71;
        }

        #changePassword .button {
            border: none;
            padding: 6px 10px;
            color: #fff;
            border-radius: 3px;
            background-color: #2ecc71;
            outline: none;
        }

        #changePassword .button:hover {
            background-color: #26ae60;
            color:#f4f4f4;
        }

        @media only screen and (max-width: 440px) {
                .row .col-md-3{
                    min-width:300px !important;
                }          

        }

        @media only screen and (max-width: 343px) {
                .row .col-md-3{
                    min-width:270px !important;
                }
                
                .textPart p{
                   font-size:12px !important;
                   vertical-align:middle;
                }   
                
                .textPart {
                    width: 50%;
                }
        }

        @media only screen and (max-width: 307px) {
                .row .col-md-3{
                    min-width:230px !important;
                }          

        } 

        @media only screen and (max-width: 266px) {
                .row .col-md-3{
                    min-width:200px !important;
                }    
                
                .navbar-brand{
                  font-size:12px;
                }

                button.navbar-toggler{
                  width:40px;
                }

                .navbar-toggler-icon{
                  font-size:10px;
                  text-align:center;
                }

        } 
        
  

       
</style>

<div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.querySelector('#myModal').style.display='none'">&times;</span>
            
            <form action="" method="post" style="margin:10px 10px;" id="changePassword">                    
                <div class="row">
                       <label><i class="fa fa-lock"></i> Password</label>
                       <input type="password" name="password" id="password" placeholder="Type your current password" required autofocus>
                </div>

                <div class="row">
                       <label><i class="fa fa-key"></i> New Password</label>
                       <input type="password" name="new_password" id="new_password" placeholder="Type your new password" required autofocus>
                </div>

               
                    <center>
                         <button class="button" type="submit" name="changePassword"> <i class="fa fa-check-circle"></i> Change Password</button>
                    </center>         
                
          </form>
          <!-- form -->

 <?php 
   if(isset($_POST["changePassword"])){
         $password=$_POST["password"];
         $new_password=$_POST["new_password"];
         $student_id=$_SESSION["student_own_id"];
         include "./db.php";
         $sql1="SELECT student_password FROM student WHERE student_id='$student_id'";
         $sql="UPDATE student SET student_password='$new_password' WHERE student_id='$student_id'";
         $result1=$conn->query($sql1);
         if($row1=$result1->fetch_assoc()){
                  if($row1["student_password"]===$password){
                    // if password match
                    ?>
<script>
    document.querySelector('#myModal').style.display='block'
</script>
                     <?php 
                    // password match

                    $result=$conn->query($sql);
                    if($result===TRUE){
                          //if password changed  
           echo "<center><span class='text-success' style='font-size:25px;'><i class='fa fa-times-circle'></i> Password Changed!!!</sapn></center>";
                    }else{
                          // if password not changed
              echo "<center><span class='text-danger' style='font-size:25px;'><i class='fa fa-times-circle'></i>Error Password Not Changed!!!</sapn></center>";

                    }
                  }else{
                    // if password not match
                    ?>
<script>
    document.querySelector('#myModal').style.display='block'
</script>
                    <?php 
                    echo "<center><span class='text-danger' style='font-size:25px;'><i class='fa fa-times-circle'></i> Password Not Match!!!</sapn></center>";
                  }
         }#fetch_assoc()
   }
?>

       </div><!---modal-content--->
        
</div><!---modal--->

<br>
<br>
<br>