<?php 
  session_start();

  if(isset($_SESSION["student_own_id"])){
  }else{
    header("Location:./index.php");
  }
?>