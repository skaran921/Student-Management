  <?php 
  session_start();

  if(isset($_SESSION["student_own_id"])){
      header("Location:./dashboard.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" keyword="Student Information System">
    <meta name="description" content="Student Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Login - Student Information System</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
   
    <!-- external css -->
    <link rel="stylesheet" href="./css/index.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="./images/icon.png" type="image/x-icon">
</head>
<body>
       <!-- main div -->
         <div class="main">
                <center> 
                    <img src="./images/icon.png" alt="logo" class="icon">
                    <p class="heading"><span class="fas fa-user-graduate"></span> Student Panel</p>
                </center>  
               <form id="form" action="" method="post">
                     <div class="form-group">
                        <input type="text" name="student_login_id" id="student_login_id" placeholder="Student ID" required autofocus>   
                        <input type="password" name="student_password" id="student_password" placeholder="Password" required >   
                      </div>                      
                           <button type="submit" name="login" class="admin_button" style="background-color:#2ecc72"> <span class="fa fa-sign-in-alt"></span> Login</button>
                      
             

               <!-- php start here-->
   <?php 
      if(isset($_POST["login"])){
          $student_login_id=$_POST["student_login_id"];
          $student_password=$_POST["student_password"];
          include "./db.php";
          $sql=$conn->prepare("SELECT student_id FROM student WHERE student_login_id=? AND student_password=?");
          $sql->bind_param("ss",$student_login_id,$student_password);
          $sql->execute();
          $result=$sql->get_result();
          if($row=$result->fetch_assoc()){
                  $_SESSION["student_own_id"]=$row["student_id"];
                  header("Location:./dashboard.php");
          }else{
                ?>
                <center style="margin-top:10px;background-color:#EA425C;padding:4px;border-radius:7px;">
                   <span class="text-light"><i class='fa fa-times-circle'></i> Invalid Username OR Password!!!</span>
                </center>
                <?php
          }
          $sql->close();
      }
   ?>
<!-- php end here -->
</form>
        </div>
       <!-- main div end-->


       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<!-- <script src="./js/bootstrap.min.js"></script> -->
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
</body>
</html>

